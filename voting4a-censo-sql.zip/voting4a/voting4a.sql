-- phpMyAdmin SQL Dump
-- version 4.4.13.1deb1
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 04-05-2016 a las 20:19:26
-- Versión del servidor: 5.6.30-0ubuntu0.15.10.1
-- Versión de PHP: 5.6.11-1ubuntu3.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `voting4a`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `candidature`
--

CREATE TABLE IF NOT EXISTS `candidature` (
  `dtype` varchar(31) COLLATE utf8_unicode_ci NOT NULL,
  `id` bigint(20) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `vote_option` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `list_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `district` bigint(20) DEFAULT NULL,
  `candidature_list` bigint(20) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `candidature`
--

INSERT INTO `candidature` (`dtype`, `id`, `name`, `vote_option`, `list_name`, `district`, `candidature_list`) VALUES
('ReferendumOption', 1, NULL, 'Sí', NULL, 1, NULL),
('ReferendumOption', 2, NULL, 'No', NULL, 1, NULL),
('ReferendumOption', 3, NULL, 'Si', NULL, 2, NULL),
('ReferendumOption', 4, NULL, 'No', NULL, 2, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `district`
--

CREATE TABLE IF NOT EXISTS `district` (
  `id` bigint(20) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `region` bigint(20) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `district`
--

INSERT INTO `district` (`id`, `name`, `region`) VALUES
(1, 'Estado', 1),
(2, 'Principado de Asturias', 2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `election`
--

CREATE TABLE IF NOT EXISTS `election` (
  `id` bigint(20) NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `end_time` datetime NOT NULL,
  `start_time` datetime NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `election_call` bigint(20) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `election`
--

INSERT INTO `election` (`id`, `description`, `end_time`, `start_time`, `name`, `election_call`) VALUES
(1, 'Referéndum por el modelo electoral 2016', '2016-05-04 20:25:07', '2016-05-04 20:08:27', '¿Estás de acuerdo con el nuevo modelo electoral?', 1),
(2, 'Referendum por la Independencia de Asturias 2016', '2016-05-04 22:30:00', '2016-05-04 01:00:00', '¿Estás a favor de la independencia de Asturias?', 2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `election_call`
--

CREATE TABLE IF NOT EXISTS `election_call` (
  `id` bigint(20) NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `election_call`
--

INSERT INTO `election_call` (`id`, `description`, `name`) VALUES
(1, 'Referéndum por el modelo electoral arobado en 2016', 'Referéndum por el modelo electoral 2016'),
(2, 'Referendum por la Independencia de Asturias 2016', 'Independencia de Asturias 2016');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `region`
--

CREATE TABLE IF NOT EXISTS `region` (
  `id` bigint(20) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `election` bigint(20) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `region`
--

INSERT INTO `region` (`id`, `name`, `election`) VALUES
(1, 'España', 1),
(2, 'Asturias', 2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `vote`
--

CREATE TABLE IF NOT EXISTS `vote` (
  `id` bigint(20) NOT NULL,
  `vote_option` bit(1) DEFAULT NULL,
  `candidature` bigint(20) DEFAULT NULL,
  `voting_place` bigint(20) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `vote`
--

INSERT INTO `vote` (`id`, `vote_option`, `candidature`, `voting_place`) VALUES
(1, b'0', 1, 3),
(2, b'0', 4, 3),
(3, b'0', 4, 1),
(4, b'0', 2, 1),
(5, b'0', 4, 1),
(6, b'0', 1, 1),
(7, b'0', 4, 1),
(8, b'0', 2, 2),
(9, b'0', 3, 2),
(10, b'0', 1, 3),
(11, b'0', 4, 3),
(12, b'0', 1, 3),
(13, b'0', 4, 3),
(14, b'0', 1, 3),
(15, b'0', 4, 3),
(16, b'0', 2, 3),
(17, b'0', 4, 3),
(18, b'0', 1, 4),
(19, b'0', 4, 4),
(20, b'0', 1, 4),
(21, b'0', 4, 4),
(22, b'0', 2, 4),
(23, b'0', 3, 4);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `voted_election`
--

CREATE TABLE IF NOT EXISTS `voted_election` (
  `id` bigint(20) NOT NULL,
  `id_election` bigint(20) DEFAULT NULL,
  `voter` bigint(20) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `voted_election`
--

INSERT INTO `voted_election` (`id`, `id_election`, `voter`) VALUES
(1, 1, 1),
(2, 1, 10),
(3, 2, 10),
(4, 2, 1),
(5, 1, 2),
(6, 2, 2),
(7, 1, 3),
(8, 2, 3),
(9, 1, 5),
(10, 2, 5),
(11, 1, 6),
(12, 2, 6),
(13, 1, 7),
(14, 2, 7),
(15, 1, 8),
(16, 2, 8),
(17, 1, 9),
(18, 2, 9),
(19, 1, 11),
(20, 2, 11),
(21, 1, 12),
(22, 2, 12),
(23, 1, 13),
(24, 2, 13);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `voter`
--

CREATE TABLE IF NOT EXISTS `voter` (
  `id` bigint(20) NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `id_voting_place` bigint(20) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `nif` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `voting_place` bigint(20) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `voter`
--

INSERT INTO `voter` (`id`, `email`, `id_voting_place`, `name`, `nif`, `password`, `voting_place`) VALUES
(1, 'perico@servidor.com', 1, 'Perico Delgado Gutiérrez', '11111111A', 'f95c141f91e483356a3977d5289bc06e', NULL),
(2, 'juan@servidor.com', 1, 'Juan Álvarez González', '11111112B', 'd799f1fd0412a10a07900922595e9e12', NULL),
(3, 'manuel@servidor.com', 1, 'Manuel Fernández Álvarez', '11111113C', 'f1c30cf0c2dba460991a84aa39121d47', NULL),
(4, 'francisco@servidor.com', 2, 'Franciso Gutiérrez Fernández', '11111114D', 'cd16c1522da17adb52bf5baf30d67cea', NULL),
(5, 'paco@servidor.com', 2, 'Paco Domínguez Álvarez', '11111115E', '3ffbfff48ac94f035bb48d0e303dedd2', NULL),
(6, 'javier@servidor.com', 3, 'Javier Sánchez Pon', '11111116F', 'b26c3a78dbe97d238724c77a96f7f661', NULL),
(7, 'manolo@servidor.com', 3, 'Manuel Álvarez Álvarez', '11111117G', '525955c057c3e7a5a34713b25070cc48', NULL),
(8, 'alvaro@servidor.com', 3, 'Álvaro Díaz Díaz', '11111118H', 'cb981a4a66484b1e99297d8fccfa6557', NULL),
(9, 'fran@servidor.com', 3, 'Franciso Díaz Fernández', '11111119I', 'f35220098272d65aa816e3148adcd9cb', NULL),
(10, 'javi@servidor.com', 3, 'Javier Díaz Pon', '11111110J', 'd1768ddd1eca078e4aeca615fd474280', NULL),
(11, 'sandra@servidor.com', 4, 'Sandra Álvarez González', '11111120K', 'b0d54c83f4a376d45a07125572b90673', NULL),
(12, 'marta@servidor.com', 4, 'Marta Díaz Díaz', '11111121L', '8c7c4c6b57f4f06086f51a0f14ec50d8', NULL),
(13, 'maria@servidor.com', 4, 'María Díaz Díaz', '11111122M', '2965caa84e8074c6ed239fcacec8f600', NULL),
(14, 'luz@servidor.com', 4, 'Luz Díaz Díaz', '11111123N', 'b0d74905737cc393d2f05c8f922569f8', NULL),
(15, 'manuela@servidor.com', 4, 'Manuela Díaz Díaz', '11111124O', 'b86fda01790dd67a79ecf5df6fb36a9f', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `voting_place`
--

CREATE TABLE IF NOT EXISTS `voting_place` (
  `id` bigint(20) NOT NULL,
  `id_voting_place` bigint(20) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `voting_place`
--

INSERT INTO `voting_place` (`id`, `id_voting_place`, `name`) VALUES
(1, 1, 'Colegio Electoral 1'),
(2, 2, 'Colegio Electoral 2'),
(3, 3, 'Colegio Electoral 3'),
(4, 4, 'Colegio Electoral 4');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `candidature`
--
ALTER TABLE `candidature`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_f2ycg4738omspx05hr8o03i0f` (`district`),
  ADD KEY `FK_e7qrvg2vj3s4xjf3psmjqcr9j` (`candidature_list`);

--
-- Indices de la tabla `district`
--
ALTER TABLE `district`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_1y0ifdi502desu80q6iobavk` (`region`);

--
-- Indices de la tabla `election`
--
ALTER TABLE `election`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_8n5k2gcdh7awv13d0o42jjcen` (`election_call`);

--
-- Indices de la tabla `election_call`
--
ALTER TABLE `election_call`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `region`
--
ALTER TABLE `region`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_nii8jwmtr3mrfcivghsu3j40` (`election`);

--
-- Indices de la tabla `vote`
--
ALTER TABLE `vote`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_av2uenyj722sk2joys7dg81oq` (`candidature`),
  ADD KEY `FK_qdmc2eb0s4w571v6u8rnwfmqq` (`voting_place`);

--
-- Indices de la tabla `voted_election`
--
ALTER TABLE `voted_election`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_1daq62246bmisg6jh2e3krpfh` (`voter`);

--
-- Indices de la tabla `voter`
--
ALTER TABLE `voter`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_3de4if7ww010yx1wxmt3ialp3` (`voting_place`);

--
-- Indices de la tabla `voting_place`
--
ALTER TABLE `voting_place`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `candidature`
--
ALTER TABLE `candidature`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT de la tabla `district`
--
ALTER TABLE `district`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT de la tabla `election`
--
ALTER TABLE `election`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT de la tabla `election_call`
--
ALTER TABLE `election_call`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT de la tabla `region`
--
ALTER TABLE `region`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT de la tabla `vote`
--
ALTER TABLE `vote`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=24;
--
-- AUTO_INCREMENT de la tabla `voted_election`
--
ALTER TABLE `voted_election`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=25;
--
-- AUTO_INCREMENT de la tabla `voter`
--
ALTER TABLE `voter`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT de la tabla `voting_place`
--
ALTER TABLE `voting_place`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `candidature`
--
ALTER TABLE `candidature`
  ADD CONSTRAINT `FK_e7qrvg2vj3s4xjf3psmjqcr9j` FOREIGN KEY (`candidature_list`) REFERENCES `candidature` (`id`),
  ADD CONSTRAINT `FK_f2ycg4738omspx05hr8o03i0f` FOREIGN KEY (`district`) REFERENCES `district` (`id`);

--
-- Filtros para la tabla `district`
--
ALTER TABLE `district`
  ADD CONSTRAINT `FK_1y0ifdi502desu80q6iobavk` FOREIGN KEY (`region`) REFERENCES `region` (`id`);

--
-- Filtros para la tabla `election`
--
ALTER TABLE `election`
  ADD CONSTRAINT `FK_8n5k2gcdh7awv13d0o42jjcen` FOREIGN KEY (`election_call`) REFERENCES `election_call` (`id`);

--
-- Filtros para la tabla `region`
--
ALTER TABLE `region`
  ADD CONSTRAINT `FK_nii8jwmtr3mrfcivghsu3j40` FOREIGN KEY (`election`) REFERENCES `election` (`id`);

--
-- Filtros para la tabla `vote`
--
ALTER TABLE `vote`
  ADD CONSTRAINT `FK_av2uenyj722sk2joys7dg81oq` FOREIGN KEY (`candidature`) REFERENCES `candidature` (`id`),
  ADD CONSTRAINT `FK_qdmc2eb0s4w571v6u8rnwfmqq` FOREIGN KEY (`voting_place`) REFERENCES `voting_place` (`id`);

--
-- Filtros para la tabla `voted_election`
--
ALTER TABLE `voted_election`
  ADD CONSTRAINT `FK_1daq62246bmisg6jh2e3krpfh` FOREIGN KEY (`voter`) REFERENCES `voter` (`id`);

--
-- Filtros para la tabla `voter`
--
ALTER TABLE `voter`
  ADD CONSTRAINT `FK_3de4if7ww010yx1wxmt3ialp3` FOREIGN KEY (`voting_place`) REFERENCES `voting_place` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
